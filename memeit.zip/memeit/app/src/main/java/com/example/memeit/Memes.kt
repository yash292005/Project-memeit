package com.example.memeit

data class Memes(
    val subreddit:String,
    val title:String,
    val url:String
)
