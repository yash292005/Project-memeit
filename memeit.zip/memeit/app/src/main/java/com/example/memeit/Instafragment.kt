package com.example.memeit

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.giphy.sdk.core.models.enums.MediaType
import com.giphy.sdk.ui.Giphy
import com.giphy.sdk.ui.pagination.GPHContent
import com.giphy.sdk.ui.views.GiphyDialogFragment
import com.giphy.sdk.ui.views.GiphyGridView
import com.giphy.sdk.ui.views.GiphyGridView.Companion.HORIZONTAL
import kotlinx.android.synthetic.main.fragment_instafragment.*

class Instafragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        this.context?.let { Giphy.configure(it, "aKl9OLRgPxOppISMXoQzlS2EKvEDtOYD", false) }
        gifsGridView?.spanCount = 3
        gifsGridView?.direction = HORIZONTAL
        gifsGridView?.cellPadding = 10
        gifsGridView?.content = GPHContent.searchQuery("dogs", MediaType.gif)
        return inflater.inflate(R.layout.fragment_instafragment, container, false)
    }

}